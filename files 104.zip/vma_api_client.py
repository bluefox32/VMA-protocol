"""
vma_api_client.py
=================
VMA Quantum API クライアント

デプロイ先API サーバーに接続して処理をオフロード
- ローカル実行
- AWS Lambda
- Azure Functions
- Google Cloud Run
- 自社サーバー

使用方法:
  python vma_api_client.py --api-url http://api.example.com:5000
"""

import requests
import json
import argparse
import sys
from typing import Dict, List, Any

class VMAClient:
    def __init__(self, api_url: str = "http://localhost:5000"):
        """
        VMA API クライアント初期化
        
        Args:
            api_url: API サーバーのベースURL (例: http://localhost:5000)
        """
        self.api_url = api_url.rstrip('/')
        self.session = requests.Session()
    
    def health_check(self) -> Dict[str, Any]:
        """ヘルスチェック"""
        resp = self.session.get(f"{self.api_url}/api/health")
        resp.raise_for_status()
        return resp.json()
    
    def get_info(self) -> Dict[str, Any]:
        """API情報取得"""
        resp = self.session.get(f"{self.api_url}/api/info")
        resp.raise_for_status()
        return resp.json()
    
    def judge_quantum_bit(self, x: float, sharpness: float = 1.0, 
                         coupling: float = 1.0) -> Dict[str, Any]:
        """
        量子ビット判定API呼び出し
        
        Args:
            x: 因果的情報量
            sharpness: 判定の鋭さ (default=1.0)
            coupling: 結合度 (default=1.0)
        
        Returns:
            判定結果
        """
        payload = {
            "x": x,
            "sharpness": sharpness,
            "coupling": coupling
        }
        resp = self.session.post(f"{self.api_url}/api/judge", json=payload)
        resp.raise_for_status()
        return resp.json()
    
    def compress_bloch(self, kp: int, verify: bool = True) -> Dict[str, Any]:
        """
        ブロッホ差分圧縮API呼び出し
        
        Args:
            kp: 圧縮パラメータ (0..255)
            verify: デコード検証を実行 (default=True)
        
        Returns:
            圧縮結果
        """
        if kp < 0 or kp > 255:
            raise ValueError("kp must be 0..255")
        
        payload = {"kp": kp, "verify": verify}
        resp = self.session.post(f"{self.api_url}/api/compress", json=payload)
        resp.raise_for_status()
        return resp.json()
    
    def quantum_fx(self, function: str, n_qubits: int, 
                   x_values: List[float], x_update: bool = False) -> Dict[str, Any]:
        """
        拡張量子FX API呼び出し
        
        Args:
            function: 正規化関数 (例: "1 + sin(x)**2")
            n_qubits: 量子ビット数 (1..10)
            x_values: 計算するx値のリスト
            x_update: 状態更新を行う (default=False)
        
        Returns:
            計算結果
        """
        payload = {
            "function": function,
            "n_qubits": n_qubits,
            "x_values": x_values,
            "x_update": x_update
        }
        resp = self.session.post(f"{self.api_url}/api/quantum_fx", json=payload)
        resp.raise_for_status()
        return resp.json()

def main():
    parser = argparse.ArgumentParser(description="VMA Quantum API Client")
    parser.add_argument('--api-url', type=str, default='http://localhost:5000',
                       help='API server URL (default: http://localhost:5000)')
    parser.add_argument('--test', action='store_true',
                       help='Run test suite')
    args = parser.parse_args()
    
    client = VMAClient(args.api_url)
    
    print("="*70)
    print("VMA Quantum API Client")
    print(f"API URL: {args.api_url}")
    print("="*70)
    
    # Health check
    try:
        health = client.health_check()
        print(f"\n✓ Server connected: {health['service']}")
    except Exception as e:
        print(f"\n✗ Server connection failed: {e}")
        sys.exit(1)
    
    if args.test:
        print("\n[Test 1] 量子ビット判定")
        print("-"*70)
        for x in [0.0, 1.0, 2.0]:
            result = client.judge_quantum_bit(x)
            print(f"x={x} → {result['verdict']:12s} "
                  f"P(Q)={result['p_quantum']:.4f} Q={result['quantum_score']:.4f}")
        
        print("\n[Test 2] ブロッホ差分圧縮")
        print("-"*70)
        for kp in [0, 42, 128, 255]:
            result = client.compress_bloch(kp)
            match_mark = "✅" if result.get('match') else "❌"
            print(f"kp={kp:3d} → m={result['m']:5d} p={result['p']:7.4f} {match_mark}")
        
        print("\n[Test 3] 拡張量子FX")
        print("-"*70)
        result = client.quantum_fx(
            function="1 + sin(x)**2",
            n_qubits=4,
            x_values=[0.5, 1.0, 1.5, 3.14159]
        )
        for res in result['results']:
            ratio = res['ratio']
            check = "✓" if abs(ratio - 1.0) < 0.001 else "✗"
            print(f"x={res['x']:7.5f} f(x)={res['fx']:.6f} "
                  f"Σ|ψ|²={res['norm2']:.6f} ratio={ratio:.10f} {check}")
    else:
        # Interactive mode
        print("\nInteractive mode - Enter commands:")
        print("  judge <x> [sharpness] [coupling]")
        print("  compress <kp> [verify]")
        print("  quantum_fx <function> <n> <x1,x2,...>")
        print("  info")
        print("  exit")
        print()
        
        while True:
            try:
                cmd = input("> ").strip().split()
                if not cmd:
                    continue
                
                if cmd[0] == 'exit':
                    break
                elif cmd[0] == 'info':
                    info = client.get_info()
                    print(json.dumps(info, indent=2))
                elif cmd[0] == 'judge':
                    x = float(cmd[1]) if len(cmd) > 1 else 1.0
                    sharp = float(cmd[2]) if len(cmd) > 2 else 1.0
                    coup = float(cmd[3]) if len(cmd) > 3 else 1.0
                    result = client.judge_quantum_bit(x, sharp, coup)
                    print(json.dumps(result, indent=2, default=str))
                elif cmd[0] == 'compress':
                    kp = int(cmd[1]) if len(cmd) > 1 else 0
                    result = client.compress_bloch(kp)
                    print(json.dumps(result, indent=2, default=str))
                elif cmd[0] == 'quantum_fx':
                    fn = cmd[1] if len(cmd) > 1 else "1 + sin(x)**2"
                    n = int(cmd[2]) if len(cmd) > 2 else 4
                    xs = [float(x) for x in cmd[3].split(',')] if len(cmd) > 3 else [1.0]
                    result = client.quantum_fx(fn, n, xs)
                    print(json.dumps(result, indent=2, default=str))
                else:
                    print(f"Unknown command: {cmd[0]}")
            except Exception as e:
                print(f"Error: {e}")

if __name__ == '__main__':
    main()
